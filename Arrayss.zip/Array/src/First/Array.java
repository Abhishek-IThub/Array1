package First;
import java.util.Scanner;
public class Array {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter Size");
		int size=s.nextInt();
		
		int numbers[]=new int[size];
		System.out.println("Enter digits");
		for(int i=0;i<size;i++) {
			numbers[i]=s.nextInt();
		}
		
		int x=s.nextInt();
		
		System.out.println("Enter Size1");
		for(int i=0;i<size;i++) {
			System.out.println(numbers[i]);
		}
	}
}
