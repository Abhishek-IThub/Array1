package First;

public class Maximum {

	//Array Object are stored in Heap area
	public static void main(String[] args) {
		
	}
}
