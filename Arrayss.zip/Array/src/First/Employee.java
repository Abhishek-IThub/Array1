package First;
import java.util.Scanner;
public class Employee {

	
	public static void main(String[] args) {
		//Zero indexed
	//	int marks[]=new int[5];
	//	int marks[]= {97,98,99,99,98};
	  /*marks[0]=90;
		marks[1]=100;
		marks[2]=90;
		marks[3]=90;
		marks[4]=100;*/
//		System.out.println(marks[0]); 
//		System.out.println(marks[1]); 
//		System.out.println(marks[2]); 
//		System.out.println(marks[3]); 
//		System.out.println(marks[4]); 
		Scanner sc=new Scanner(System.in);
		int size=sc.nextInt();
		int numbers[]=new int[size];
		
		
		//input
		for(int i=0; i<size; i++) {
			numbers[i]=sc.nextInt();
		}
		
		
		//output
		for(int i=0;i<size;i++) {
			System.out.println(numbers[i]);
		}
	}
}
